#!/usr/bin/python3
import http.client
import urllib.request
import urllib.parse
import json
import time

import Adafruit_DHT
import Adafruit_BMP.BMP085 as BMP085

# Carriots connection info
api_url = "http://api.carriots.com/streams"
device  = "defaultDevice@raspiq.raspiq"  # id_developer of the device
api_key = "6b3dc1699019d36feca5a1d53d127a26c0a5c2a6c1a46403455f57d5501f1a9e"

# Sensor 1 (temperature and humidity)
sensor1 = Adafruit_DHT.DHT11
pin = 23

# Sensor 2 (pressure)
sensor2 = BMP085.BMP085()

# Read measurements
humidity, temperature = Adafruit_DHT.read_retry(sensor1, pin)
pressure = sensor2.read_pressure() / 100 # Measured in HectoPascals

if humidity is not None and temperature is not None and pressure is not None:

    print('Temp={0:0.1f}*C Humidity={1:0.1f}%'.format(temperature, humidity))
    print('Pressure = {0:0.2f} hPa'.format(pressure))
   
    # Time variables
    timestamp = int(time.time())
    now = time.strftime("%d/%m/%Y %H:%M:%S")

    # Parameters - Body (data)
    params = { "protocol" : "v2",
               "device" : device,
               "at" : timestamp,
               "data" : dict(
                   temp = temperature,
                   hum = humidity,
                   pres = pressure,
                   time = now) }

    binary_data = json.dumps(params).encode('ascii')

    # Header
    header = { "User-Agent"   : "raspberrycarriots",
               "Content-Type" : "application/json",
               "carriots.apikey" : api_key }

    # Request
    req = urllib.request.Request(api_url, binary_data, header)
    f = urllib.request.urlopen(req)

    # Print results
    data = json.loads( f.read().decode('utf-8'))
    print(json.dumps(data, indent=4, sort_keys=True))

else:
    print('Failed to get reading. Try again!')


